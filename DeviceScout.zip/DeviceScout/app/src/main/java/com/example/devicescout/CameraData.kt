package com.example.devicescout

import android.content.Context
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object CameraData {
    @Volatile var cams: List<DoubleArray> = emptyList()
    private val lastAlert = HashMap<Int, Long>()
    private fun file(c: Context) = File(c.filesDir, "cameras.json")

    private fun parse(s: String): List<DoubleArray> {
        val a = JSONObject(s).getJSONArray("elements")
        return (0 until a.length()).map { val o = a.getJSONObject(it); doubleArrayOf(o.getDouble("lat"), o.getDouble("lon")) }
    }

    fun load(c: Context) { try { cams = parse(file(c).readText()) } catch (_: Exception) {} }

    /** Downloads ALPR camera nodes (OpenStreetMap/Overpass) around a point. WiFi only. */
    fun update(c: Context, lat: Double, lon: Double, done: (String) -> Unit) {
        Thread {
            try {
                val cm = c.getSystemService(ConnectivityManager::class.java)
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) { done("Connect to WiFi first"); return@Thread }
                val q = "[out:json][timeout:60];node[\"man_made\"=\"surveillance\"][\"surveillance:type\"=\"ALPR\"](${lat - 1},${lon - 1.5},${lat + 1},${lon + 1.5});out;"
                val conn = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.doOutput = true; conn.connectTimeout = 15000; conn.readTimeout = 90000
                conn.outputStream.use { it.write(("data=" + URLEncoder.encode(q, "UTF-8")).toByteArray()) }
                val body = conn.inputStream.bufferedReader().readText()
                cams = parse(body); file(c).writeText(body)
                done("Loaded ${cams.size} cameras")
            } catch (e: Exception) { done("Update failed: ${e.message}") }
        }.start()
    }

    /** Index of a camera within [meters] of l (10-min cooldown per camera), else null. */
    fun nearby(l: Location, meters: Float = 150f): Int? {
        val r = FloatArray(1); val now = System.currentTimeMillis()
        cams.forEachIndexed { i, c ->
            Location.distanceBetween(l.latitude, l.longitude, c[0], c[1], r)
            if (r[0] < meters && now - (lastAlert[i] ?: 0) > 600_000) { lastAlert[i] = now; return i }
        }
        return null
    }
}
