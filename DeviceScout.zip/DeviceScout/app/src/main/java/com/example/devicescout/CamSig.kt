package com.example.devicescout

/** Heuristics for IP/hidden cameras broadcasting their own WiFi. Unverified; edit freely.
 *  SSID matches notify; OUI matches are weak (logged only). */
object CamSig {
    val ssids = listOf("ipc-", "ipcam", "hdwificam", "wificam", "yicam", "ezviz", "hikvision", "dahua",
        "v380", "icsee", "ycc365", "smartlife-", "cam-", "mini-cam", "spycam")
    val ouis = setOf("44:19:b6", "c0:56:e3", "bc:ad:28", "4c:bd:8f", "28:57:be", "a4:14:37",
        "3c:ef:8c", "4c:11:bf", "e0:50:8b", "9c:8e:cd")

    fun match(ssid: String?, bssid: String?): String? {
        val n = ssid?.lowercase()
        if (n != null) ssids.firstOrNull { it in n }?.let { return "name \"$it\"" }
        val o = bssid?.lowercase()?.take(8)
        return if (o != null && o in ouis) "OUI $o (weak)" else null
    }
}
