package com.example.devicescout

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists the sighting log so "seen repeatedly" works across days and app restarts. */
object Store {
    private fun enc(l: Location?): Any = if (l == null) JSONObject.NULL else JSONArray(listOf(l.latitude, l.longitude))
    private fun dec(a: JSONArray?): Location? =
        if (a == null) null else Location("saved").apply { latitude = a.getDouble(0); longitude = a.getDouble(1) }

    fun save(c: Context) {
        val arr = JSONArray()
        synchronized(ScanService.log) {
            ScanService.log.values.forEach {
                arr.put(JSONObject().put("a", it.addr).put("l", it.id.label).put("k", it.id.kind.name)
                    .put("r", it.rssi).put("f", it.first).put("t", it.last).put("n", it.count)
                    .put("e", it.encounters).put("al", it.alerted).put("fl", enc(it.firstLoc)).put("ll", enc(it.lastLoc)))
            }
        }
        try { File(c.filesDir, "log.json").writeText(arr.toString()) } catch (_: Exception) {}
    }

    fun load(c: Context) {
        synchronized(ScanService.log) {
            if (ScanService.log.isNotEmpty()) return
            try {
                val arr = JSONArray(File(c.filesDir, "log.json").readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    ScanService.log[o.getString("a")] = Sighting(o.getString("a"), Id(Kind.valueOf(o.getString("k")), o.getString("l")),
                        o.getInt("r"), o.getLong("f"), dec(o.optJSONArray("fl"))).apply {
                        last = o.getLong("t"); count = o.getInt("n"); encounters = o.getInt("e")
                        alerted = o.getBoolean("al"); lastLoc = dec(o.optJSONArray("ll"))
                    }
                }
            } catch (_: Exception) {}
        }
    }
}
