package com.example.devicescout

/**
 * Community-reported, UNVERIFIED signatures for Flock-style ALPR cameras. Edit freely.
 * Name matches are "strong" (notify). OUI matches are "weak" (logged only): many OUIs
 * belong to common chipset vendors and will produce false positives.
 */
object FlockSig {
    val names = listOf("flock", "fs ext battery", "penguin", "pigvision")
    val ouis = setOf("58:8e:81", "cc:cc:cc", "ec:1b:bd", "90:35:ea", "04:0d:84", "f0:82:c0", "1c:34:f1",
        "38:5b:44", "94:34:69", "b4:e3:f9", "70:c9:4e", "3c:91:80", "d8:f3:bc", "80:30:49", "14:5a:fc",
        "74:4c:a1", "08:3a:88", "9c:2f:9d", "94:08:53", "e4:aa:ea")

    fun match(name: String?, mac: String?): String? {
        val n = name?.lowercase()
        if (n != null) names.firstOrNull { it in n }?.let { return "name \"$it\"" }
        val o = mac?.lowercase()?.take(8)
        return if (o != null && o in ouis) "OUI $o (weak)" else null
    }
}
