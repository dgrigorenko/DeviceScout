package com.example.devicescout

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var out: TextView
    private val h = Handler(Looper.getMainLooper())
    private var repeatedOnly = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun sw(label: String, key: String) = Switch(this).apply {
            text = label; isChecked = p.getBoolean(key, true)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean(key, v).apply() }
        }
        root.addView(sw("Alerts (master)", "master")); root.addView(sw("Tracker alerts", "trackers")); root.addView(sw("Camera proximity alerts", "cameras"))
        val cam = TextView(this)
        CameraData.load(this); cam.text = "${CameraData.cams.size} cameras loaded"
        root.addView(Button(this).apply {
            text = "Update camera data (WiFi)"
            setOnClickListener {
                val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
                val l = try { lm.getLastKnownLocation("gps") ?: lm.getLastKnownLocation("network") } catch (_: SecurityException) { null }
                if (l == null) cam.text = "No location fix yet: grant permission and start scanning once"
                else CameraData.update(this@MainActivity, l.latitude, l.longitude) { msg -> runOnUiThread { cam.text = msg } }
            }
        })
        root.addView(cam)
        root.addView(Button(this).apply {
            text = "Start / stop scanning"
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.POST_NOTIFICATIONS), 1)
                val i = Intent(this@MainActivity, ScanService::class.java)
                if (ScanService.running) stopService(i) else startForegroundService(i)
            }
        })
        val lan = TextView(this)
        root.addView(Button(this).apply {
            text = "Check this WiFi network for cameras"
            setOnClickListener { lan.text = "Scanning..."; LanScan.run(this@MainActivity) { m -> runOnUiThread { lan.text = m } } }
        })
        root.addView(lan)
        root.addView(Switch(this).apply { text = "Seen repeatedly only (3+ encounters)"; setOnCheckedChangeListener { _, v -> repeatedOnly = v; refresh() } })
        root.addView(Button(this).apply { text = "Clear log"; setOnClickListener { synchronized(ScanService.log) { ScanService.log.clear() }; Store.save(this@MainActivity); refresh() } })
        root.addView(Button(this).apply { text = "Export CSV"; setOnClickListener { export() } })
        Store.load(this)
        out = TextView(this)
        root.addView(ScrollView(this).apply { addView(out) })
        setContentView(root)
        h.post(object : Runnable { override fun run() { refresh(); h.postDelayed(this, 2000) } })
    }

    private fun snapshot() = synchronized(ScanService.log) { ScanService.log.values.toList() }

    private fun refresh() {
        out.text = snapshot().filter { !repeatedOnly || it.encounters >= 3 }.sortedWith(compareBy({ it.id.kind }, { -it.encounters }, { -it.count })).joinToString("\n\n") {
            "${when (it.id.kind) { Kind.TRACKER -> "[TRACKER] "; Kind.CAMERA -> "[POSSIBLE CAMERA] "; else -> "" }}${it.id.label}\n${it.addr}  ${it.rssi} dBm  ${it.encounters} encounters"
        }.ifEmpty { "No devices yet" }
    }

    private fun export() {
        val f = File(getExternalFilesDir(null), "scout_log.csv")
        f.writeText("address,label,kind,rssi,first,last,count,encounters,lat,lon\n" + snapshot().joinToString("\n") {
            "${it.addr},\"${it.id.label}\",${it.id.kind},${it.rssi},${it.first},${it.last},${it.count},${it.encounters},${it.lastLoc?.latitude ?: ""},${it.lastLoc?.longitude ?: ""}"
        })
        Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
    }
}
