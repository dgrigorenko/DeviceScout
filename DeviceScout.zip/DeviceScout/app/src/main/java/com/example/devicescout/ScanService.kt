package com.example.devicescout

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.IBinder

class Sighting(val addr: String, val id: Id, var rssi: Int, val first: Long, val firstLoc: Location?) {
    var last = first; var count = 1; var encounters = 1; var lastLoc: Location? = firstLoc; var alerted = false
}

@SuppressLint("MissingPermission")
class ScanService : Service() {
    companion object {
        val log = LinkedHashMap<String, Sighting>()
        @Volatile var running = false
    }
    private var loc: Location? = null
    private val locL = LocationListener { loc = it; checkCamera(it) }
    private val cb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) = handle(r)
        override fun onBatchScanResults(l: MutableList<ScanResult>) = l.forEach(::handle)
    }

    private val h = Handler(Looper.getMainLooper())
    private var wifiOn = false
    private val saveLoop = object : Runnable {
        override fun run() { Store.save(this@ScanService); h.postDelayed(this, 60_000) }
    }
    private val wifiRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val wm = applicationContext.getSystemService(WifiManager::class.java)
            try { wm.scanResults.forEach { w ->
                FlockSig.match(w.SSID, w.BSSID)?.let { track(w.BSSID, Id(Kind.CAMERA, "Possible Flock camera (WiFi: $it)"), w.level) }
            } } catch (_: SecurityException) {}
        }
    }
    private val wifiLoop = object : Runnable {
        override fun run() {
            try { applicationContext.getSystemService(WifiManager::class.java).startScan() } catch (_: Exception) {}
            h.postDelayed(this, 35_000)
        }
    }

    private fun handle(r: ScanResult) = track(r.device.address, classify(r), r.rssi)

    private fun track(addr: String, id: Id, rssi: Int) {
        val now = System.currentTimeMillis()
        val s = synchronized(log) { log.getOrPut(addr) { Sighting(addr, id, rssi, now, loc) } }
        if (now - s.last > 300_000) s.encounters++
        s.rssi = rssi; s.last = now; s.count++; loc?.let { s.lastLoc = it }
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val f = s.firstLoc; val l = s.lastLoc
        if (p.getBoolean("master", true) && p.getBoolean("trackers", true) && s.id.kind == Kind.TRACKER &&
            !s.alerted && now - s.first > 10 * 60_000 && f != null && l != null && f.distanceTo(l) > 300f) {
            s.alerted = true
            notify(2, "tracker", "Tracker may be following you", "${s.id.label} seen for 10+ min over ${f.distanceTo(l).toInt()} m", NotificationManager.IMPORTANCE_HIGH)
        }
        if (s.id.kind == Kind.CAMERA && !s.alerted && !s.id.label.contains("weak") &&
            p.getBoolean("master", true) && p.getBoolean("cameras", true)) {
            s.alerted = true
            notify(4, "camera", "Possible Flock camera nearby", s.id.label, NotificationManager.IMPORTANCE_LOW)
        }
    }

    private fun checkCamera(l: Location) {
        val p = getSharedPreferences("p", MODE_PRIVATE)
        if (p.getBoolean("master", true) && p.getBoolean("cameras", true) && CameraData.nearby(l) != null)
            notify(3, "camera", "Camera nearby", "Known ALPR camera within 150 m", NotificationManager.IMPORTANCE_LOW)
    }

    private fun notify(id: Int, ch: String, title: String, text: String, imp: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, ch, imp))
        nm.notify(id, Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title).setContentText(text).build())
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (CameraData.cams.isEmpty()) CameraData.load(this)
        Store.load(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("scan", "Scanning", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "scan").setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("DeviceScout scanning").build())
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000, 0f, locL) } catch (_: Exception) {}
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner
            ?.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build(), cb)
        if (!wifiOn) { registerReceiver(wifiRx, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)); h.post(wifiLoop); h.postDelayed(saveLoop, 60_000); wifiOn = true }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        if (wifiOn) { h.removeCallbacks(wifiLoop); h.removeCallbacks(saveLoop); Store.save(this); try { unregisterReceiver(wifiRx) } catch (_: Exception) {}; wifiOn = false }
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner?.stopScan(cb)
        (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(locL)
        running = false
    }
    override fun onBind(i: Intent?): IBinder? = null
}
