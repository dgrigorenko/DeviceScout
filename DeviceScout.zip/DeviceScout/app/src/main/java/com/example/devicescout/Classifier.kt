package com.example.devicescout

import android.bluetooth.le.ScanResult

enum class Kind { TRACKER, CAMERA, BLE }
data class Id(val kind: Kind, val label: String)

fun classify(r: ScanResult): Id {
    val rec = r.scanRecord
    val apple = rec?.getManufacturerSpecificData(0x004C)
    if (apple != null && apple.isNotEmpty() && apple[0] == 0x12.toByte())
        return Id(Kind.TRACKER, "Apple Find My (AirTag/accessory)")
    val u = rec?.serviceUuids?.map { it.uuid.toString().substring(4, 8).uppercase() } ?: emptyList()
    return when {
        "FEED" in u || "FEEC" in u -> Id(Kind.TRACKER, "Tile")
        "FD5A" in u -> Id(Kind.TRACKER, "Samsung SmartTag")
        "FE65" in u || "FE33" in u -> Id(Kind.TRACKER, "Chipolo")
        else -> FlockSig.match(rec?.deviceName, r.device.address)?.let { Id(Kind.CAMERA, "Possible Flock camera (BLE: $it)") }
            ?: Id(Kind.BLE, rec?.deviceName ?: "Unknown BLE device")
    }
}
