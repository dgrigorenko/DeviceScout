package com.example.devicescout

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Checks the WiFi network you're on (/24) for hosts exposing common camera/DVR ports. */
object LanScan {
    private val ports = mapOf(554 to "RTSP", 8554 to "RTSP", 8000 to "Hikvision", 37777 to "Dahua", 34567 to "DVR/XMeye")

    fun run(c: Context, done: (String) -> Unit) {
        Thread {
            try {
                val cm = c.getSystemService(ConnectivityManager::class.java)
                if (cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) {
                    done("Connect to the WiFi network you want to check"); return@Thread
                }
                val me = cm.getLinkProperties(cm.activeNetwork)?.linkAddresses?.map { it.address }
                    ?.filterIsInstance<Inet4Address>()?.firstOrNull() ?: run { done("No IPv4 address"); return@Thread }
                val base = me.hostAddress!!.substringBeforeLast('.')
                val pool = Executors.newFixedThreadPool(64)
                val found = Collections.synchronizedList(mutableListOf<String>())
                for (h in 1..254) for ((p, n) in ports) pool.execute {
                    try { Socket().use { it.connect(InetSocketAddress("$base.$h", p), 300) }; found.add("$base.$h|$p|$n") } catch (_: Exception) {}
                }
                pool.shutdown(); pool.awaitTermination(120, TimeUnit.SECONDS)
                val now = System.currentTimeMillis()
                found.forEach {
                    val (ip, p, n) = it.split("|")
                    synchronized(ScanService.log) {
                        ScanService.log["$ip:$p"] = Sighting("$ip:$p", Id(Kind.CAMERA, "Possible IP camera/DVR on network ($n, port $p)"), 0, now, null)
                    }
                }
                done(if (found.isEmpty()) "No camera ports found on $base.0/24" else "${found.size} possible camera service(s) found, see list")
            } catch (e: Exception) { done("Scan failed: ${e.message}") }
        }.start()
    }
}
